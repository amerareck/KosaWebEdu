package day3;

public class TimeTest {

	public static void main(String[] args) {
		int time = 32150;
		System.out.println(time/60/60+"시간 "+time/60%60+"분 "+time%60+"초");
	}

}
