package television;

public interface Rentable {
	public void rent();
}
